function mostraCarregamento(loading, anyFunction, ...anyParam) {
	loading.show();
	setTimeout(function () {
		anyFunction(...anyParam);
		loading.hide();
	}, 300);
}

const carregandoFuncRM = FLUIGC.loading(window, {
	textMessage: 'Carregando dados do RM - Funcionários admitidos nos últimos 90 dias'
});

function dataTableWEXRM(paramentro) {

	if (paramentro == true) {
		try {
			var tabela = $('#RMWEX').dataTable();
			tabela.fnDestroy();
			$('#RMWEX').dataTable({
				data: DatasetFactory.getDataset('dsDDG204FuncAdminitidos90Dias', null, null, null).values,
				dom: 'Bfrtip',
				buttons: [
					{
						extend: 'pdfHtml5',
						filename: "INCLUSAO-WEX_" + data(null),
						text: 'PDF',
						title: "Código: 602292	CNPJ: 18.725.804/0001-13",
						orientation: 'landscape',
						pageSize: 'A1', //formato stampa
						alignment: "center", //non serve a nnt ma gli dice di stampare giustificando centralmente
				 
						className: 'btn btn-primary',
						customize: function (doc) {
							doc.content.splice(1, 0, {
								margin: [0, 0, 0, 12],
								width: 100,
								alignment: 'center',
								image: imagemWEX
							});
						}
					},
					{
						extend: 'excelHtml5',
						sheetName: "Código: 602292	CNPJ: 18.725.804/0001-13",
						title: "Código: 602292	CNPJ: 18.725.804/0001-13",
						filename: "INCLUSAO-WEX_" + data(null),
						text: 'EXCEL',
						className: 'btn btn-success',

					},
					{
						extend: 'copyHtml5',
						text: 'COPIAR',
						className: 'btn btn-info',
					}
				],
				header: [
					{ 'title': 'Nome' }
				],
				"language": {
					"url": "//cdn.datatables.net/plug-ins/1.10.19/i18n/Portuguese-Brasil.json"
				},
				"pageLength": 10,
				columns: [
					{ data: 'ID', className: "ID" },
					{ data: 'CODCOLIGADA', className: "CODCOLIGADA" },
					{ data: 'PCARTAOWEX', className: "PCARTAOWEX" },
					{ data: 'CODIGO', className: "CODIGO" },
					{ data: 'CHAPA', className: "CHAPA" },
					{ data: 'CPF', className: "CPF" },
					{ data: 'NOME', className: "NOME" },
					{ data: 'LIMITE', className: "LIMITE" },
					{ data: 'DTNASCIMENTO', className: "DTNASCIMENTO" },
					{ data: 'CARGO', className: "CARGO" },
					{ data: 'DATAADMISSAO', className: "DATAADMISSAO" },
					{ data: 'MAE', className: "MAE" },
					{ data: 'NACIONALIDADE', className: "NACIONALIDADE" },
					{ data: 'RUA', className: "RUA" },
					{ data: 'NUMERO', className: "NUMERO" },
					{ data: 'COMPLEMENTO', className: "COMPLEMENTO" },
					{ data: 'BAIRRO', className: "BAIRRO" },
					{ data: 'CEP', className: "CEP" },
					{ data: 'CIDADE', className: "CIDADE" },
					{ data: 'ESTADO', className: "ESTADO" },
					{ data: 'TELEFONE1', className: "TELEFONE1" },
					{ data: 'EMAIL', className: "EMAIL" },
					{ data: 'CODFILIAL', className: "CODFILIAL" },
					{ data: 'FILIAL', className: "FILIAL" }
				]
			});


			setInterval(() => {
				if ($('#RMWEX').dataTable()[0].innerHTML.length > 1000) {
					/* Ajusta tela */
					var larguraTela = $('html').width();

					if (larguraTela > 0 && larguraTela <= 1920) {
						$(".ID").css('display', 'none');
						$(".CODCOLIGADA").css('display', 'none');
						$(".PCARTAOWEX").css('display', 'none');
						$(".CODIGO").css('display', 'none');
						$(".LIMITE").css('display', 'none');
						$(".CARGO").css('display', 'none');
						$(".DATAADMISSAO").css('display', 'none');
						$(".NACIONALIDADE").css('display', 'none');
						$(".COMPLEMENTO").css('display', 'none');
						$(".CIDADE").css('display', 'none');
						$(".ESTADO").css('display', 'none');
						$(".TELEFONE1").css('display', 'none');
						$(".EMAIL").css('display', 'none');
						$(".CODFILIAL").css('display', 'none');
						$(".FILIAL").css('display', 'none');
					}
					if (larguraTela > 1920) {
						// Não faz nada
					}
				}
			}, 300);


			return paramentro;
		} catch (error) {
			console.log(error);
		}
	}
}

$(document).ready(function () {
	if (atividade == 0 || atividade == 1 || atividade == 'null') {
		setTimeout(() => {
			mostraCarregamento(carregandoFuncRM, dataTableWEXRM, true);
		}, 300);
	}
});

function data(valor) {
	var novovalor = valor == null ? Date() : valor;
	var data = new Date(novovalor);
	var mes = data.getUTCMonth() < 10 ? "0" + (data.getUTCMonth() + 1) : (data.getUTCMonth() + 1);
	var ano = data.getUTCFullYear();
	var dia = data.getUTCDate() < 10 ? "0" + data.getUTCDate() : data.getUTCDate();

	var novaData = String(ano) + "-" + String(mes) + "-" + String(dia);

	return novaData;
}

const imagemWEX = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADICAIAAAAiOjnJAAAAAW9yTlQBz6J3mgAAMlNJREFUeF7tnXecVOXVx895ntum7WxfFlBAVAQLGhU1YkNFRDpRFBuWxBrNa2JLjCWxBUvsUbGXqBQVLEhU7AW72Cii9F22zk67c8vznPePXVBgZnZ22dld4H4/fPhj73mm3d899zznOc+56DgOeHh0NKw1Aw+P9uAJyyMveMLyyAuesDzygicsj7zgCcsjL3jC8sgLnrA88oInLI+84AnLIy94wvLIC56wPPKCJyyPvOAJyyMveMLyyAuesDzygicsj7zgCcsjL3jC8sgLnrA88oInLI+84AnLIy94wvLIC56wPPKCJyyPvOAJyyMveMLyyAuesDzygicsj7zgCcsjL3jC8sgLnrA88oInLI+84AnLIy94wvLIC56wPPKC0pqBR1eDCACAAARA1Jp1d8ETVneFMWAMAfBXfyMAAgApQcpM47oJnrC6GYjAebOYSIBYvdr6ZjHUN4IkKCnS9xrA+vZCxoAxAgDhQnd1YZ6wuhOKAgDMda3vljoLvhbf/OAuXCqXrxIJExDQ0FO79FN2H8D3203fb2+++87AFSQiIVp73S4AvQcIdD2IwDkAgABr/vuph2c4H38pqmuIcdQUUFREAAICAMchx2HAoLLEOGSIcfYkZeh+KoDofq7LE1aXgojNkjKTqXkfpma8bL3xISRSpHLUVEAEwE2DLCCQRK4DlsOKw77TxhkXnq5XlgspQHYjcXnC6iIYQ8Y4gG3Z1pw3U4/PdD/83E3YPGBAi6Rag4gsm5qi+mEHhB68Qd2lH3WnoN4TVqfDGDIGALIxar44z3xmjvzsW3Jc0nVU2x7yCkFxU9ltp/DDN6r77EHdxm95wupEFI6ADMBeW23NmZ96eo77/RJK2hDSkamQg5NKjyCKNGmH7lfw3zvU8lIpRHdId3nC6hQUjoAEIFdXmU/PNp99RS76kRQFNQ00tbXBOSCEiCSCk48LPXYLApDjtl+mHYQnrDyjKC058x+WJJ9+xXztbbn0JyROfqMjzz0iWLZ03PDD1wePHy1IgujiYMsTVr5ARUEACeAsWmY9Ois5Yy6tXAMBA3UDeD6WaImaEurgXYvmPMzKishxcpoB5A1PWB0NInJGgATkfPBF6pk59tz3RHUtaArqWn5PtuuSaQev+WPo0t9LIujSxKknrI4EFYUAiMj54FPrqdnWq++ImibQGRo6sHx4qY1BpEiU775r8WsP85LirnVabZ/femzO+gU+IaQz773UI9Pt9z93IjHu17HQ33lnlwiDfveHH1MvvB48exIpShc6Lc9jbRkbUufRuPnau6lnXnQ+WUiRJBkqqkrnSWoDRGSltEG7FM5+kJUWk+u2NiBfeB6rvTBExgFANEbtuW+bj8ywPl0Ito2GgSEfdr6kmkFERbW//N6aM9935u+Asa7KxXvCajucN+tGrqtNznrVfmau9d0PzAFmaOD3tTY4/3BVAqSmv2xMHoOGRl0kLO9W2BYUBQEYgL16berFN6zpr1hfLWIkUdNAU6AjE1Nbhu0QYsH9/wz+7ljRRQuInrByAAF4S55Trl5lPjw79dwce/laxgF1H6i8tfFdAMWSykF7l7zyMGpql0RanrBaQ1FYc57zm+/tma+bz78mV1YREPp0wPxnENqN64Ijwv+9zT9yWJdU1HgxVkaaU+cAkPrs29STz9svzhfVa0HzoU/HvKTOOxTORSyRenKOPnwYKpxkZzstz2NtBiJyTgAkHOfdL1JPvWi/8b6oaQS/hmpulVLdA7JtVNTwk7f6hx8iOr3kwfNYG9GcOpe247yzwHrqpeT896G2EXw6hgNbkaSaQU2Dhmjq6Ze04Ycwzjs50vI8FgD8UnznWq6c/05s2izx9gInmVD8/lzrObsllExhSC966VFjn0Gd7LS2e2ExhowRgIxG7dlv2bPmmR9+gpZNqtaees7uBhHFTd9p48P3XUcA0IlOazsWFmPIGAOwm+Lu7NfjDz0nvvhWCsF8vq3aS20CpSzm9xW+/JC2zyASDlAnfa+t/6JsBxtKhFevTj33mjnrNVq0zHVd7g8w3km/e6eBuipq6q2n52j7DAKudprT2s48FirIgQDk8pXmzHmpZ1+2F69g5IDuR6075jk7BEqkWM/ywpcf0HbuR50VaW0fwvp16nzR8uRTz1nPz7d/WslUFX16y2bRbRgpZTIRvPCM4E1/AeikSGtbFxYC8vUlwl99bz07x5oz31m1DjmgZsA2d+NLDxFZLq8sKn75Ub7TDp1TALjtxliIwDkHcAGcTxamnnjBnv2GWFcHhs78nVLP2X1ARJW7P64yZ84LXXY2qQq4eS8A3BY91oZWCNKx3vwk9eQLzlsfiEgSVERN74SLtTuCQHGT79y3ePYDfIcenbA/bNvyWAjIFQJA00y98VFq+svW/A+hPkp+A7c3L7UJBGhoculP5oy5oUvOIIXle3/YtuKxNtRzppLu7LfijzwnPv7GdVLcFwBt27p42g0hxaN88KCS1x5loWC+I62tX1jrq85FbZ396jup6a86n35NSZt8GnIl3w5/K8MRYNvBu68LnT5O5Hl/2NYsLM4RkQFY9Q32rHnWEy86n38jAdGvo6a1Nnj7hCie0vYZEH7lYR4K5XVZeuu8TWxInS9fm5r5ij3zf873S4gBhvyMb53fqJNA1FX7ix/sl9/xnTQKGOavAHBrOw0KInACcJYut6bPSc34n71sJUNCzUCFeze+1lFVmYynnp1tTDoWWR4LALeaWyEqCgAQgPPtYuupF8yZr8k1daAyNPLUCmHbxbIJlcLHb9RHHQV5q1reCoSFisIAXCL54VeJ52bbc98V62qBKair23UGod0QgJnQj/hteNa9yJU8RVrdW1iKwgFcIPfjrxIPPefOe0+sqYUCP+qaJ6ktgRwXhQxPv9d/9EF5KgDsljHW+npOsuzkmx+knpztvP+JbIiRoWJFcWuDPVoHVS7iZuqpmcZRBwHn+ViW7mYea0NSKpa03v7Yfnq2Nf9DiJnk03AbKr7rDpBlo89X9PTtxuEH5MNpdRuPxRkiAwAZj5mzXjeffkF+/I0rXO7ToDCA3nyvo0FNE/X1iSdf0A4/IKPTQgDA9mmuGwhrg6Rq6sw5r6eeftVZ+B06Nul+zrfXNeNOAIEZfnf++9ZX3/v2HiRwUwHh+iaXANCORt9deitcnzq3q2pSM+daj7/g/vAjkUSfH1RvNSb/kJRNSf8fTgjfefVGWy0QOeduNG59/CWrj8DAnYy9d5dA4Li5X+ddJKwN3TWWLk/NmGvOeFUuW0kMUFWbnyfj0TlQymHhYOGc+7W9BrYsSyMC5+6SZfHr71H79YXeFeLThbyiKHjNn0lhuYf5nT5pV1hzqtP5Zmn0ujsiJ/wxeuO9YukKMDT0+bYyVTWfhg3/tkJQ52J1tTVrLgGAqgAAck6Rpti1d6v7DmYD+qEEY8Jwe9HK5JOzOEDuWZ7OOpGIyHlzibD9/RLrgWfMV96WK6rAb/CAP+vHzXTCco8o075C7sM3B0ESuC45NgnR/EqIgJoGqgKMt8S8W/QWnQUy9OvmjNf9fziJ96okRASwXv8AbccYPSz2t9uUvr3sVatDfzwlfsvDvjFHQ0lhjsFWpwiLMcaYG2myP/rSnv6a/b+3RVUdGDqWFmYbhQCuANtOf5Qx0PX0hzYgBVguQLofIpfhv6ZZK45DKYtSSVAIND/zBZhPBwVAIjiuTCQp2USOy0DHgAaqAZxtOqVCAEGUNLNNtYhQVcFvtG86BgAARAkLpJvtsuQcgz6QgIZBa9aajz8f+usF1Fx525QAVQFFxWjc/XmVdvhBUFFKqSS4VoZXS0M+YyzGAJGkZJw5H32eePAJc+48aEhR0EDdYIhAOuBmP/16EJkgG8BKc6NBQoczRSfJ0usGAJCRdEixQdJm9ylCoSAasP6RpdlABAKIm048wlRSduqrD9lH3WuAMmBXZecdeLgQFABg0nTE2jXOkuVi0WJrwUJ74UKqj4Hq44WFoKhA6z+kkFAY1AqDdjSOmd5aUWRNPZoOFBSAbGPJFAKAIhprWUUJ8/mB0g0nAEVVQiG7qhpTDiCnVIr36FEy/1HWswcAOD/8GL3shuAFZ4i6WnWfwdbrb2MyJeJmwQ2XElKO9fL5EdaGPKcjVCRhu3LFKozFQDFA5wDIiwuSby1oOudSVAtAT+c1icS62tDvTwpd9yfZFNlooZSAhQL24iWRUy+XKRt9RprhALK+0Td2WMHUK8ARm4ScrKDAWfhdw1l/BhPBl9VvEYhkjMVi1KvMP/aowMTRfPAgpaSV7D+5JBcvSb77sTl9VmrBD+AIpagMFAZEYKagQCl+7gHjN3vKSBQkpfEpwYC98Nu6352JTS4WlrRJW0jMqV1lHHtY6X9uhYIAmKk0RqrCgv7YEzOaLrmB6QFQFRBCxpLBf11WcNHpEgABkk/NNp+b4z9hNN9jF2fma9YX34Sn3cR7V+a+l7qjb4W/pM5j5oxXVE3TTpmgKAoM3GUTQ61/X+kQ12SmcIRAUDjAK8t4ZdnmR1XLJSAQAjZLwLTguBgKqf36pDkEIJNxIoFZvj5DcEnWroPSoP+Cc4JnTlZ36ZfReGNQQb77gNDuA/xnn+K89Grk349YH3+h6CEMh8BnUF1d9Ppb9BefYhWlmV7B+O2Qwjv/EZnyZ5ZMks/3i8PLDlPs6nVav8qSh29jFRUAAOFQWkPry29jV92Mig6aCkSgKMiZ89xL4qTjWFkpAQVOGctLC1PzP8KPPld27hua9i/eu4KEyFFV0JGzQsZQUZBzEWkyH53ROOa82Fl/sr9blMmcUqnWYggEK6M3pVgcCLLNxRCzzI0pYYLMMpZDY1zU/KxPHFb54cuFN/0td1X9Gq5yY8LoHu+9UPyf6zCsirWrAACLeiRefavpjD9lHxs8fkLo8vOtyDIQuc3wkVMiqhhOwf1TebOqMkDReOMp5zo1cfQHWk4BERq6/c2P5vRXAQAESSJ9xGHhqVcE7ro2cMlZau8Kct3WztdGdISwEFFROGPOmrWJ+56Ijj0vcsmN4tOvJerM1w26CLcR5Fw2NgjNLrznxrIZDys798n1Is1M6OwpZW8/b4wZKtdVgW0ZJTvGn5sdv/fh7KPCf7s0MGE81dXk9AFcy22qKfjXXwNHHZ7NTELtGeeJRau1yt4b3WRVLqVrz3yNTBM5A9cl4RIRV7iUsh2lNVssLEVROKd4Inr3E7Fx58X/76bU5wsZVyAY2CpLOhnaa9byMr38xcdDF5zVmnUbUHfpVzr72cD5k+26ZYTIgiUNl1yVevOdbGM4FD9yL+7Ww66tBZYtaEGmuLVrg6eND134hyxmANB0w7+Tz7+EZRVEm2gFuWFYn32bmvMmAgDnQABCkOvmmF/YhC0QFgJTFACIzZxbf9xZiatusxf/DOEgCwW7ZyPhVkHOZW2N0r+i7OWn9cMPbM28zSBA0T03Fd10rahbDUzhGGo870qqqssyhIeDpQ/coRSoMhIBzPCrMrTXLteG7ld0/x3pDdYTf+7F2A3/1sM7pW/Lq3IJmJr2rIgnMOdEaCbaOx6RuCJiifjlN8fOu1osWAiqigH/VtxggylOTZ1SVlA25zFlr91bs24/4SsuKrj8AtGwlhWVOj+uqj/zQsqa8tCGHlhw/RVuch046dJIjFEsrlYES+++iWWd4bpLf47+5WriPgr4MiRZkBua9cnC1P/eYQDAtuh20y5hITLOqao+evKf47c+DERQVABbdf87ZJCIAbcKpt2mDdqtNesWKJaQVXVybbWsbaDGKDm55gXCN//NOG2iXb1MLdsx+tq86OXXZ7cPnT8lfN7pom7lpk9SQSYTpozVFT1wh7J3totBmqm6E89xqmM8XJotf8GZtIT19EsCoHkDcLtpuxoQkXM3loiee0Xq9Q9YSdG2sJdBStFUUzj1Kv/IYdkNCcBdvDQ1713nvY+sn1dAxAKXg87Qj7ysVBu4qzb8UG3oATzDPH8DpXdeX/31Qrmk1lfSP3bnNL77rsHTJmWxL7rnFufHn83XP1F79v4lqyddN7qu+G8X+saOyDIWACJ/udr+4mutoj+lTZluAJGFDPv9L6zX3/cfPVRswf6wtmuCcwRIXnWLPe895vdvC6piTNTXab/dN3TpBdkNxbqapouvXnfY+IaL/5qc9ab4ZpVYWytq14mVa5zvV6fe+qzprsdrR42tnfwHEK2cDywMF93yDwkmIBIEmi692lqyJNsAhsV3TFV7BEQ0As2+BJlYtzI49qjQ9X/LNhAgetcD8f88oRTvSNh6GI6cQyKVevAZSQBb4LTaKAvGGEBixqvJR56X/gDoHfGg7K4FUcZTEFSKb78me0yRfH5O9W9HRe+axpJMrejHevRgJUWssJCFw6yoiJcU8fIePFCAwZ7F551BOXTeMo4+LHDiBKtuNS8tdZtk46RzZGNDFntlUP/ix+4jMkVTHLgqa2uwX5+iB27P/k6p+R9G/vxPJdQj/QrH5jBGPsV6Z4H17gIOWTOFWWmbsJAxYZrWtGeFbTNda1PGrLuCIrouMG6EesD+WYxi/3msbspFclW90qMPBAOAAESb/rNtN1FVeMPl2qjhOZ4N/wWnKYEgJOJaSbn91TeRP12T3d44ZljhX86HRJ1sbMRCXvz4Xbw8Y/oeAMSqNY2XXM7RgGAg95OFjFOTmXrmZQnQ7tlYW4TFGABYc96wPl3Ig4HWl2+3AhAsm2uq74yTshjFH34qcv7/KTzEyyoBIMMZQrduZfDc00MXnZ3uaHqMfQcb40bKZBMRKWU7x5+YFZ16V/YhoWsv8006JpX8ruD6K/2HHJDFkgAaf/9n++slWFrZpgVHYAwCeurVt60FX7XbabVNWATSmvk6uhKUrf8mCACAMhnThx7gGzokk4X18afRv97AjF7gK4BMG9IZF9Vr9EMOKLl7anqDzARPGweogG2DwpTi8sjVt6TmvpHFHgEKrvlb2dU3h846NYsZAET+eqM5732tvB9Qm+sMUFOopj71xIvtdlptEBYCiCUr7e9+IIZtGdd9QRJSOMbEYzPmbFy38fy/yloTSwrTl6AAAHLRWM8rwiXTbgWlLedAUPKFl2JT72fBEDAGJEEPgNAbz7lCrFiVZZw2sH/4usuzv1d8+qzETbfxoopcor00IANDs+bOtxf9hNAep5WzQBgDAOejL6imHreBmB0AEJ1kQikqMIYdmskk/tB/nS8XsoryjCvBiGCaYEeLpk1VBmxawZEJt64pdu8jNQcMr5t0sfneV6BpoDAAABJqeYW9al39ORdlKjPLBevrH6KX/IP8PcBof7UgarqobbAemwnQHqfVBmERgLtwMSVSgLnNL7o96LpK30rWp3faozJlJp6cTmpBlmwfuiCaakJXXewbfWwmm18jq9fE7n2w9ojxDRdea329SgmXKiXFQL/k3kkKrby3Ne/jhktbCeQzIRPxxikXyqooL8zsZXNBQVQUc8Zce8mPCJkiy4zkKiwEIMty6+qJM8C2vUd3BAGkBHCUXQdyX/oubda7H9tfL1ELCzIWqTJm1y4xJg4PX3t5eoNfIZZXNf39xqqDJzRdeI1cVq2WV/Kyopbqv40hTrykV+z2u+OPPpX2pbLT+Mcr7K++ZRVtDNg3hwB1XaxcbT3zKgC0dZ9LrsICACCJknItOtsKIAmu2i+9uwIA593PIWkRy9AcEBk11Gp77V56581ZAhACEEsWN11+/bph45qunwa1Jivvg4VhYJl3GBOApiuByujf/2V//lV6mwxEb74z+egLSlm/jjlNiGj4nFfmO7UNm64mtUabhMUAYJu5D4IkAAaVGfNA7qKfkTikjS6QU2NUclHy1L3YszydBQCA+82iyAWXVx04tnHqfbImrlSUYyAALIfbCgkMF8mqeP1J54rGWCvG67He+Shy3W3cX9wSsXUEqGv20hXi1bcAIPe9X5C7sAgAVc58OsCWOdjuAxECx0B6h0S246xdS4ae7jaIYFuuVV942zXanntufhgArAUfN5zxp6pDxiQfmMmkrlXsyAoKALENyT/psopKd+mqyDl/lvFEa9bgfL2w9vQLOAtAYahj3FUzKpcOpea8LgW0qZYmd1NCRcHelUis3QuT3Q4uATMIyzLBNTPoQMr6VaGLzw6dc/pmw8B8/Z36k86pPeb05GMvIvqwrAJ8/pZMfdvB4orEjOftdz5ozRDMp2eKFYswlOu+v5xBpoH9zU/u0h9bs9yInIUlJAFo++/FwgHq4I/edUiATQspW0DdQFWFzUtgOZfVa5WhBxT/+58b/V1S8sV5646a2DDq1Piz8wCCrLKSGf7m99j0RXJEuk7DytAF5xojhrdmCoE/XaDueQDV1mzJynFakClUXeUuXt6mhFbOwiJCAGW/vZTeleC0ra6+m9K8vSeZfkMsahpW7ICb7OZgnGpq+K49S564Z8PfKBZLPD2jdsTxDade6L77NQbL1cpK5leBqP2SAgDG3brawFFDC2+7On2ctzG8Z0XFk/fKCp9sbOxgbXFGtpCLlxO0IczK1Q4ACIiVFanDDyYhOvIu3lUgEki5ribTcX1QP0nmL7kGRIibQkaL7r5R7bcjAJCZiD/4TPXhE+pO+WPqjc+ZXoBlZaApv85LpSGXdg/IqbpG7VVa9OQ01HPtWc8HDyq+9e/CjoCZ6sjdBojEiKpqCNrgsdoyxRMSOdcnjTb/+4psjKCxZZcFtUnVeQARQXF/rs50XD1oH+b3gUOgIgBI26ZoddG0243hR8poJD7t6cTTz7tfLWVaQC3fEbgCJFtz5AiuKy0bhAuAoHCm66DwTUchF2YMuFn8n3vVHmn2VGYhMHmS+/2K6A1TefnOHfrzKpRKgevmns1qy5sTEZC25wBjxCEymcxpzSGbwHGLGmcgtXYWs8bLiAAMQbUWfQ+p9C0J9EMOVnfrT4koAAMiSiZDl54ZnHhc7Nb7q39zXOSym8W3q3lpJRYXtqz0ZQEZOMKN1MpoE/iQVxbyyhAyoqZGamoC2CiWQ9uGeGP4+st8I1sPrTan4B+Xakcf5tZVb2Ft8cZI8GltusPmKsAWhGSc66eMNWe8RK6DWtZFQ0TK1NIDADgDhCzKQiCmZrwLkMKBK4CZ1+2Rsq1w2S6QQF2Xy1a6K9YpA3bc3IQV+Px/OLnx/KsUGaaUaQzqjwXlVQcfK35Yg/6gUtqzpedHq/pmituwDuykdtzw8MnjtSGDSdMBOEWjyVdeSzz4jKyLMdVoWQjn3K7+yX/yuILLLmrlZTOADMuem7Zu6Bjnh9VKZa8tzb8DAJEUxEqLkCG1+mXX0xaPBQBEAkA/cB995JFoOdkvUwSQyXS9AwAAgAV11NSsq0PEwoFMx5TCMKpKtj5gjNCXeY1PCJAu+nwUS5rz385kpuzYj2kqCIl+v1vbFL91Gq1I8B6VLJw1df5rOJe1a7WdK8tmPNRjzqO+SWN4vz5Krx5KrzJ1YP/wXy4oe/s5pV+FTCQAAJDRumr9oH1L77i5tdfNBisqLrrnJlAI44nco6KMICoKx/47IkDuuYw2CgsApGCMGWeeAIZGdubzighIVFef6TgLF2IgSHamD4oADvTOmBbHYAjCqsxUIEUokaBH5px4XYRMG7kKElKzXklvU9sYveZa5DpoCgCSZaHuw3AAIDdJAQByWV3F+paVzH7SNyH9KjWXqqhqBERgnKIRGaCi/0zF0uK0xs3Yn31Zd9o50sx8NwAwjjik6Na/p+LVWdoU5AjZNpQXa7vuTNCGbFw7hEUSQD9siHbY/tI0s5oqYmVdplCM77SDOnAAmWba+QtaNvoNZWDGnVhYFNL33FmmkumP2g5j3Nh/77RHAUDURShlA0dWELY++MR8/5PNberPu9j5dAn4ArKmVlRXgUugKLn/ssBQVK3GnYorZj+m7tQnk1Xs7odEdQ0LBaWZoFSy+L5/6YPTZ/NbsNyGP/8z9uSDsZtuz2YGELro7MKzJrkNqyHtT5wrhLbUduvHd+/XmuVGtF1YACQFAuinjlVCQbIyXTeEimGvWOmsrspgAP7TxkpIoC02cteIgMyO1BjHHOE76DeZxgKAMflEAAfM1KZbhBm3G6u1fQf6jjk8/UgA98efW2YPquambPux6ZsYRK+/y5z1KgKIeMQ48ZjQFec4doTqGoDl0BWSIQh0165lOxWWPHoPHzgwk6FYXZX470weLAAC0bg69JcpgcnHZzJupuGyq+x3P1JDg2O33G/OTO9rNxD+9w3aQfvLdWuy79DPAjmSKahNHME0g9qSY2qPsJqXdHwjjlCH7C1NJ9NFjIZBK1aIzA1ngqcer08Ykar/RiYSIBEIQCKYKVG1mA+qLLrvpkwDm/GPOrLwynPcyM9uYyMIguZ8pOO6a1fwgCy4+e9ZtqY53ywEUIEzANKLKqLTX3Y//3rD0eR/Z9X8/WJFCWqTj+vx5jOlT91beNOVpQ9NxQrdWbtMxmLrm7ml++cKWd3g1C7SD92r/M3ZxsHZtuon7nnYXr2GBcNu9WpjxLCCm6/JYgwAsWlPxu56TCnpxQqCyP2N51zkLlqaxZ4FgkWP3I7FGkXq2zSna4EQEgm2xy6+k0YDALhtEBa/+uqrW7NJD1dVqXN7zpvIefqErMJlNML77GAceXCaowAA4B92KDbE3CVLqSlKVoyshARhjDuq5P471b5pZmqboB95BGPgLloka+ukbVIygcLS9t2taNqdvsN/m2mUu3JN/OYHQBA2zzoVlRJRe9mSwKknIID99sf11/+rYPiowgemFvzxbL5Dz+ZR2u4D/WNHkrRpxSpn3TpIOUgEJEG6IFxwbEqZ1FgvyVEG9Qr/9ZKif/+Dl2XLQlmfftVw2XWaWuREGtSdKstfeooFMk5WAMD66JOGUy/iehH6DJASdZ9ojLlffun73ZgsSVSltETduX/8xZe55G2rnEYExyEpQtderO+3F8m2rU21v6MfKoqMmY2jTnO+XIqBdG31EN36en3X3hWf/S/7pjb7y6/tdz9yqiJKcUD77f7a0AM33GzE0uVUWKCUZQtmnaUrUm+8SWtqpa7oe+2uH3M4M9K3+Wsmett/YpdPxeJy+KUeXMrqnwruvbXg/Cmx6S/6+vZWhuyXabizZJk580Xr9U+s5csw0gQCAEEGfGpxmTZ4oD7qcH30sUowm0QAAISsPmiE+OpnDBS4oq58+qPGiGFZzCkeW3fwKHvhT0rPHX/JICBzq5YFzjyx5OE7s4wFgOjVNzf88yatx6A2iEMIEYkHTxsTeuhfCNDWTkbtFxZwxpCZj8+KXHw9qiztvh0UrtvUVPjvv4bOP2Pzo60i11av3euQgssuKrjsj63Z5oqMJWqGHCNW1mO46FfpEqSUCTxR8sw04+jDswz/BRJi+VpRUw+OCwqyYAHrXc4Kw60Na6H+oisTdz+ulFS69auK7vtX6Lxsvw8B1IycbP3vA7W856aZJFfIyNqC2/9e8MdzM4wGACCS9cefmZz1hlq5Y06hkpRUH9UO+03BrPvUwkLZ9ofttCvGasaVBKBNPEbbawAlrLQhLSk6U5To1P/IhobNj7ZK45U32/Urko/NlLUZ0xZtJXb3NGvRjxgMb5yEI/QH3CZqvPAKZ/mKjIN/DXLebwftgL21oftpB+6r7LFL7qqK3nhb8r7H1bLeVF9rnPK77KoCgOgNd5hz5ypFlWnyk6rC/GWRS29MvfF+uqEtILKiB+9UB+1k165rPZAnSQ1NygF7hO64VikslLLNqoItEhYCScmDQX3SKBAOOOlcJQkMF8oVq6NX35DmaFai/7oz+cSzvvLf2D8sjVzZ5uFpSb35bvSmO7WinmnqBaTQKirsH2tqh50gF/+UZnBHQADRm+9suuoWHqq0a6vZb/coe/Su7EPMmS80XXerXrwTpF3mIIJgABy14bxLqL4xnUULvDhcNO0WxQARi2RstUVEyRQ2RJWD9w4/dou+564kZfvK79ofvAMAEAFjSu8K580PRE0jqjyt32JGyPrgUwwG9IP23fxoWlIvv15/7mVKYTmoOjN89uef814V2j5ZEzyt4Sxf0XDCBSKSZAWF6S9BIiUUlKvWpN56V9t/T96rZxqbLSN65XVN19+pFPUi1+FFetnMh3iPbP1CnSXL6iZfADbDQEHmGnnigTBVrbW//tI/aUKWyhZlh95YVmQ9/wJqwU2nzETkWGg6rChonHtK4R1/V3tXirY/m2kDWyYsAGDIQ0EnZtpvvYeKln7nJ+dSMOe1edC3lz54jzQGG+MsX9Uw8SyZkKygCEgA1ySg+cIcbc9d1N0GtDY6Pc7iZbUjJstlVUr27SsEGC5xV6xOPPcc799H2z1jCqqtOKur6if/IfnoDKW4txRSROtKH79dP2xoliHSsurGnCoXreJlPVrbyCXRF059tUDawnfUoVns9H0Hu+vWpd79gIXKWiqCiMiyIRbj4UJ19OGh2/4WOHU8+n2yjd1sN2GLhUUSGFf6VFpz35c1dWikbSpHzKcDqOazz5Pt6EcOzZZhlFR7/Onimx+V8sr1YRAxVUUHk3NfY8UF2m/2zjI6LebL8+pPPN9dWct79mj9EiTJgkFmgfnsS/aSJfp+e7FwrsFTeiTFpj3eeNaf7U8WKxU7AONO/fKiqy8Mnv/77OOaLrw0OWce79E3p+o3JG4Umm+9pfTpre2d7erVjz3a+fBjZ+HXzB8m04Rkiu3Qw3/axNA/L/Gdf7LSsweQBLGlS9dbLCxAYMgLQqKq2v7gS1R5+v6WRKDpTNFS89+xPl2g7tKf96pMYwbQ8Ke/m8++zCt23GRijD4fJsmcM0esq9P22ZOFgmmHb4JYWx278Y6GS/+BSeBlJbmGCwSgGcg1+5Ovki++Qq6t9umHBa1lEDZHOMlX50cu/Gv8nqdkipSyUkB0q1cGxh9bdP9t2fP3sbseitx4r1q0A+S+R56r6JD5wbuBY45g5RlTaIioD9kn8dLLUNWE/fsFpkwM/fMS38ljsWc5I4C2TwDTsgXphg0gIVftxT/Hxvzeqa5Ff+YW3IhA0q2uQR/zn3Bc6Pwp2j6Df90JNz7tsfo//Ekt2SV9e1xEsKTbsEbpWxm86Ozg5PGsIuMys1yxKvbo9MTjM9zlK5XCSvC1vekSIgCjaEQkoqx3WWD8SP/JE/V9dwellZJOAhA/rzJfnZt4erZY8L2LpBZXNG/JokgTH1Be8cFr6M+WaUu9+3H9sAngL8NgsLWb4MYw7q6r1nbrWf7BKyxckMXQfP0d651PfWdM5P37YfNF3MZMVXY6QljQ8vzB2BVTE3c+guGC9E5rA8gglaJokwwZxp67Kvvvp+05QN1lB7GuMXLRlTLiYEFBRuePAAAUjQsrru7UWz/4AH3oEN6/L+9RgppOQojqGrFomfXOh9b7nzqrqrivAENtqUfYHEQgCXFTppowFFYH9tH320fZew+lVw+sKMZAALkCUlLSFJEmubbKXbTc+uRz97vFoqoeUcVQEFSt5eukLPCrRf/5p37IQTIWByk2Xx1mfr9Ysbru7P8Ti1ez4tLWb9ybgcicqp+CU04ovPka6Vrgipav77qYcsCnYXkp+PygsOZfhCDXx+O0iQ4SFiLn3Fy4ODLyLEokMkRaGw0AQEglRSJOjoMgIKCjVNDwo8/fem0aIrhSxmIylUAQLOjHcBCZj1yHzCYZMQkYCwWYLwiMtSHXnIXmlcF4UlgJsF0AB3wGCwZQ0VD1geuQtCgZF1ETgQFy9PuZv7mH9K/e3RUY8vHiQlEfASkgbdEBVygakSmHhQtb/x0yQUiRJigNMUUDkmA70jQJFW3/gcaU8f4JY0BXgBAY5kNSzXSQsABQUQggds5Viadms5C/9RIAAGiuL5ASSIIrARmoSht00PwWwgVXkiuAJCCiooCiAGdA0IaXypHmd2z+wEKCkNTccwARAFHhwBkw1jLh39xHIoKUlEwBiYy/DxFwFX3GFn14BBBAySRZFjkWKLpxyP76yaN9xx4OPctRtFqb3wF0mLAAETi3P/u6aeKFsimKW+HDTjqR7FddR5x12wHLwbBPHbKvfvIY/ejf8nABALTjseHto7Xsfu4QAYC+32Bj+ND4oy9wT1jZ6AjppIWILAfiUSgtMo45Uj97kn7EEBWZAKAOmu7lSMd5LFgfac3/uGnyxdJxUMt1Q5xHB0BEtgWW5BXF2vCDjRNGqYcdqHCUACTc/Ck5Ex0qLABUFAkUOeGPqVfe40E9942zHu1HSHIsSFq8vEQbe1TgrOP5Pns0z1k62Uv9mo67FQIAAEmhMB449yT77QXguuA5rbwiJCVTwIj17mmMP9o4cZS6524IQEAyb9O9HOlgjwXrp4eR8eeY897jWXN0Hu3HFeTYKAXfuY8+frgxaZy+ax/ZHOjKLrjxbU4HeywAICk44/rksc7bn0q7tU2tHm3Fdihlo3TZ7rv5Tx7tO/E4VlnRnF7IX1KqHXS8x4Jmp5U0IxMuMN//lAdzzGl5tIYrwTJJ1dR9BhonjPKPOgJ7VgAAgWzTNofOoeM9FgCQlOj3aVNGW28vACFy7yThkRaybEqkIKAZ+wzWpoz1HT+SBQMAQM152m5JXjwWNE8PI9HIcWfaCxdj0N9aStAjHUTkuJg0sSCoHrqfceIY7ZihPBiELp3u5Ui+fAkR8cICffJY+/vbwJFb6cN8uwwCsmx0HRYIqGMP0k8c6x95KGg6AJAUuRb/dCn58ljNtTQyGoscM8X+5gcsCHfzK6y7ICVZNiRNXlqkHneEcdp4bej+KqILHVYp1Tnky2MBIZHkBSF90ijnyx9AuO3ZibtdQUSmBSR5Rbk28hBj8nhjyJ6ASADuViWpZvLmsQCAAFVFrFzbMPIMsbIag/6t7tfpJKQk05EpU9+5t3bcEfrpv1P3GMCaK9K3Qkk1kzePBQAIBMB27Ok7ZXzshvvQcdu2xXt7QAhKpCSitnNPY8Jo7eRj1f47IQCBkO5WqacN5NNjQUukJVataRhxllhdjQGjOySFuwXkUtJFlGzXnXwTjzEmHKvt2relO0KHlgh3Ffn0WABASEDKDr2MUcPidz6Khp7xyYDbCUTkOJSwGCe+50D/2b/TJ47UisISQHTLPGe7ybPHghanZX+7ODbhQmddTbatFts2BCRctGzUVfWAvY3xx2rjjuQlRdCJxXedSZ49FjQ7LdD2GMDHHurc+V/w6a1stdgmsS1h2gpX+BFDgqdPUo47hBsGbKOSaib/HgsAEJFz97Pv6sedSQk7h60W2wpEYDuUTEFx2Hf4EP2UCeqwA5mh49aQOt9COkVY0PIYxegZlyVn/I8FtW3faRFRykHbopIi/2FD9DMnqgcPQV3dHiTVTGcJC5Fznvr0y8jY82TKzv0xHlsfQlLKhpTJy0v46GGh08fzA/dVWp4HtS1M93Ik/zFWM0QSQNl/H2PEocknX4JtUlhSkmkjk2qvHtr4o7SJo4x9BzW7JtEVVeddS2cJC4CEUDjXjh+VfOF/YDuwLRUACklJU0qp9elhTDxWm/I7dee+61Pn252kmuk8YTU7Lf3IA41hB1lz391GhOW4lLIlgLbnAOP4Y30Tj2V9eiIACZAZnoS4ndCJwmouANQ07YxJ1rufkrWVR1rCJdNBJHXwbvrxxxgnjNR6VkoAIqIt7gG0DdBZwft6UFFIUmT02eabH/PC4NZXtUxEtkPJFFOYuv8e+pQTfMcNY6WFsE0npdpBp3osACApOWP6SaOtBV+DlNke0NXdICDHQctmQZ/624OME0dro47ghWHYbjIIbaKzPRY0Vy3Hko3jz3U+/gyD4awPAOseEIHtuGZSDYW0ofsbU8apw4/ghgqel8pMZ3ssACCSSsjvO3WM89HnQA5gF3yGXCEi0wbHhqKi0Pgj9ckT1MP3R65sP3nOdtMFHqu5AFDWRyIjTrcXLceA0R0jLSKyUmBJ3qNYH3GofuJo9eB9kXNPUjnSFd4CgYh4SaF++gT7yttACuBd8TEy0bxvPZXiO/TWJgwLnH08GzhgQ+rcE1SOdIXHAgAiVFVZ3xg57mz726VY4O8WWUQSZLpIDtupr2/0MO13I9TBg5p96Xa1GtMhdJGrQCSSvKRInTDc+mIhur429AbOB44gy5RCaP12NE4eq50yRt2xd3PLV09S7aOLPBa0RFr2zytiI89y1tZhwNc1gYtwKJZCn84G7ew7caRv3AjWu0c+ughvb3SRx4KWrRZavz7qpFH27Q9h5+8PcwUkU9Kn6gcO1k8eo487Wist8VLnHUXXeSxoKQAUP69oGD5FrGvAoK8zIi0isG0Zt1hAZQf8Jjhlojb2yObGll5SqgPpOo8FAEQEoPTrY4w/Jn7PEyiM/G61aEmdOxD0+8YfrE8e6zvyYAj6wcsg5IEu9VjQ4rTsH36KjD1brq3DUADy4bWIyLJF0lSLCrVD9zV+f6J+xEHNDeJgK2mFsNXR1cICAIUjYPz2B6OX38aLCzo40pKSTBtsm1eW68ceop80Rj3wN9jcocSLzfNJNxBWc06rKRoZf669YCGGgh3T8ogkpWyQgvcs1448xDh1jHrgbxDAS513Dt1AWADAkDOe+uL76MRznOo6Vli4RTdEIcg0pU1a3x76iWP0yaPUAf3XdxHeTus5O5/uISwA4Jwjxp9+MXrR9SRsZvjas4BIgMmEZIrWfwdt4gjf8SPYLjt5SakuoUtnhb/GdYWq+k8eh0CxS6e6dREeDrahiYgjKGVK4Sp7DgpNGqlNHqtUljU3pqbu1PJ1+6HbeCwAIAJVRQDng8/jN9xrvr2AMY6GClzJmIYgAiEhkSRN1fYepJ802j/uaKwoBeimLV+3H7qTsJpRFACgxqbk48/b01+xvluKUgDjoHBAhkgAjIiACFwXBJFPM/bfW5s0Qht5pFZWRF6es3vQ/YQFAACoKAAgahvs9z61539of/YNrGuglEVSACNkGqoMepRp++6pjztKPWQIN3QAICFzenyyR/7ppsICaMmdAgBJKRsaxPIqaoxQwgSuoK5hWQHv2ZOVFTPGyMsgdD+6sbCaQQTeUlLz6ziLNvzvSapb0m1mhZkggvV1mwTrxeUJqdvT7YW1CZ6kthK29XZCHl2EJyyPvOAJyyMveMLyyAuesDzygicsj7zgCcsjL3jC8sgLnrA88oInLI+84AnLIy94wvLIC56wPPKCJyyPvPD/DjwNoQ7gE9MAAAAASUVORK5CYII=';
