/* Dev: Evaldo Maciel
	evaldomaciel17@gmail.com
 * */
/*Declarando atividades */
var zero = 0; 
var inicio = 4; 
var analiseDaNecessidade  = 5;
var categorizacaoMudanca  = 11;
var formPreench = 19;
var aprovaSuperior = 13; 
var aprova1e2 = 55; 
var aprova3e4 = 67;
var aprovaSuperiorSol = 65; 
var documentaEEncerra = 59;
var qualidade  = 109;
var aprovaTISustentacao  = 75;
var aprovaTIComite = 33;
var realizaImplementa = 39;
var realizaImplementaTeste = 103;
var preparaRotTeste = 31;
var efetuaTestes = 44;
var aprovaTIProd = 25; // antes era 29
var aprovaTIProdComite = 25;
var deployProd = 91;
var finalizaTicket = 96;
var roolback = 100;
var documentaFim1e3 = 59;
var documentaFim3e4 = 71;
var fim61 = 61;
var fim73 = 73;
var fimSucesso = 98;

