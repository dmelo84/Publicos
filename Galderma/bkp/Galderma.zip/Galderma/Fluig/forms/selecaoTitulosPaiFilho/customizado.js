/*Diogo Melo*/			
function setSelectedZoomItem(selectedItem) {
			
			var dataAtual = new Date();
			var dia = dataAtual.getDate();
			var mes = dataAtual.getMonth();
			var ano = dataAtual.getFullYear();
			var dados = selectedItem
			var cCampo  = dados.inputId
			
			var aIndice = selectedItem.inputId.split("___")
	    	var nIndice = aIndice[1]
			
			var total = $("#total").val()
			var linhas = $("#linhas").val()
			
			if (dados.inputId == 'titulo___'+nIndice) {
				
	    		/*
	    		 * $("#"+selectedItem.inputId).val()
	    		 * Retorna a seleção do Zoom */
	    		 /* Inicio da leitura*/
//	    		 $('table[tablename=ingre] tbody tr').not(':first').remove();
	      		
	      			row = nIndice;//wdkAddChild('ingre');

	      			$("#empresa___"+row.toString().trim()).val(dados.Codigo);
	      			$("#nome___"+row.toString().trim()).val(dados.Nome);
	      			$("#prefixo___"+row.toString().trim()).val(dados.Prefixo);
	      		  //$("#titulo___"+row.toString().trim()).val(dados.Numero);
	      			$("#parcela___"+row.toString().trim()).val(dados.Parcela);
	      			$("#tipo___"+row.toString().trim()).val(dados.Tipo);
	      			$("#valor___"+row.toString().trim()).val(dados.Valor);
	      			setZoomData("titulo___"+row.toString().trim(),dados.Numero);
	      			
	      			if(total == '' || total == 0){
	    	        	$('#total').val(parseFloat(dados.Valor))
	    	        	linhas = $("#linhas").val('1')
	    	        }else{
	    	        	total = parseFloat(total)
	    	        	total += parseFloat(dados.Valor)
	    	            $('#total').val(total.toString())
	    	            linhas = parseInt(linhas)
	    	            linhas++
	    	            $('#linhas').val(linhas.toString())
	    	        }
			}
}

/*Função setZoom */
function setZoomData(instance, value){
    window[instance].setValue(value);
}

/*Função delete Zoom*/
function removedZoomItem(removedItem) {
    
	var dados = removedItem
	var cCampo  = dados.inputId
			
	var aIndice = removedItem.inputId.split("___")
	var nIndice = aIndice[1]
	
	row = nIndice
	
    if (dados.inputId == "titulo___"+nIndice ) {
        //--window["cmpc7filent2"].clear(); limpa campo zoom
    	$("#empresa___"+row.toString().trim()).val(dados.Codigo);
		$("#nome___"+row.toString().trim()).val(dados.Nome);
		$("#prefixo___"+row.toString().trim()).val(dados.Prefixo);
	  //$("#titulo___"+row.toString().trim()).val(dados.Numero);
		$("#parcela___"+row.toString().trim()).val(dados.Parcela);
		$("#tipo___"+row.toString().trim()).val(dados.Tipo);
		$("#valor___"+row.toString().trim()).val(dados.Valor);
		window["titulo___"+row.toString().trim()].clear(); 
//	    $('table[tablename=ingre] tbody tr').not(':first').remove();
		totalAtual = parseFloat(total) - parseFloat(dados.Valor)
		
		if(totalAtual > 0){
			$('#total').val(totalAtual.toString())
		}else{
			$('#total').val("0")
		}

    }
}

/*Função de inicialização de pagina */
function init(){   //Função executada quando o script é carregado
	
	var hdi = $("#hdi_etapa").val()
	
	   if(hdi != ''){
		   $("#inputAdicionar").attr('disabled', 'disabled');
	   }
	};