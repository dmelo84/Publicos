function displayFields(form,customHTML){ 
	 var codigo = parseInt(getValue("WKNumState"));
	 var api = fluigAPI.getUserService().getCurrent();
	 
	 log.info(">>>>>>>>>>> " + api);
	 
	 //Edição dos campos
	 //form.setEnabled("b1_cod", false);
}