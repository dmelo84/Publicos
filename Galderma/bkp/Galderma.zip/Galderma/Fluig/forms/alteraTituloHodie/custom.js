var dataAtual = FLUIGC.calendar('#venctoaltera');
var datareal = FLUIGC.calendar('#venctoreal');