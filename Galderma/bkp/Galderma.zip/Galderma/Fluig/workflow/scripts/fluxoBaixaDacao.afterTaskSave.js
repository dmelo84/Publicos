function afterTaskSave(colleagueId,nextSequenceId,userList){
	
	var atv      = getValue("WKNumState");
	var nextAtv  = getValue("WKNextState");
	var obj      = {}
	var nLinhas  = hAPI.getCardValue('linhas');
	
	console.log("L I N H A: "+nLinhas)	
	
	if(atv == 9 || atv == 14){
		
		for(var i = 1; i <= nLinhas; i++){
			
			empresa = hAPI.getCardValue('empresa___'+i)
					
			obj = {}
			console.log("Linha: "+i)
			
			if(hAPI.getCardValue("titulo___"+i) != ''){
				obj = {
						empresa  : hAPI.getCardValue('empresa___'+i),
						filial   : "01",
						prefixo  : hAPI.getCardValue('prefixo___'+i),
						numero   : hAPI.getCardValue('titulo___'+i),
						parcela  : hAPI.getCardValue('parcela___'+i),
						tipo     : hAPI.getCardValue("tipo___"+i),
						valor    : hAPI.getCardValue("valor___"+i),
						alias   : "SE2",
						processo : getValue("WKNumProces").toString(),
						atividade: getValue("WKNumState").toString()
					}
				/*/Log do Objeto/*/
				console.log("Objeto Titulos: "+obj)
				
				/*/POST/*/
				try{
		            var clientService = fluigAPI.getAuthorizeClientService();
		            var data = {
		                companyId : getValue("WKCompany") + '',
		                serviceCode : 'baixaTitulos',
		                endpoint : 'http://localhost:8084/rest/BAIXA_TITULOS',
		                method : 'post',// 'delete', 'patch', 'put', 'get'     
		                timeoutService: '100', // segundos
		                params : obj,
		             headers: {
		            	 TenantID : '99'
		             }
		            }
		            
		            console.log(JSONUtil.toJSON(data))
		            
		            var vo = clientService.invoke(JSONUtil.toJSON(data));
		            var retorno  = JSON.parse(vo.getResult());
		            
		            console.log("RETORNO => "+vo.getResult())
		            
		            if(vo.getResult()== null || vo.getResult().isEmpty()){
		            	console.log("ERROR => "+err)
		            	throw err
		            }else{	 	                	                	                
		                if(typeof(retorno.OK) != "undefined"){
		                	lVez = true;
		                	console.log("OK => "+retorno.OK);
		                }else{
		                	console.log("PARSE => "+retorno.errorMessage)
		                	throw retorno.errorMessage
		                }
		                console.log("lVez => "+lVez)
		            }
		        }catch(err){
		        	console.log("CATCH => "+err)
		        	//throw "catch "+err
		        }
			}
		}
	}
	
	/*/Adiciona o obj no array alista/*/
	//alista.push(obj)
	/*/Exibe em console o que o sistema montou/*/
	//console.log("Array  Titulos: "+alista)
	
}