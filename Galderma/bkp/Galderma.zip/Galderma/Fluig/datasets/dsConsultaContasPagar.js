function createDataset(fields, constraints, sortFields) {
	
	var ccod="";
    
	var servicoURL = "http://localhost:8084/rest/BAIXA_TITULOS"//?ccod=" + ccod;    
    
    var myApiConsumer =  oauthUtil.getGenericConsumer("","", "", "");    
    var data = myApiConsumer.get(servicoURL);    
   
  
    var dataset = DatasetBuilder.newDataset();       
    
    var objdata = JSON.parse(data);    
   
    dataset.addColumn('Codigo');
	dataset.addColumn('Filial');
	dataset.addColumn('Prefixo');
	dataset.addColumn('Numero');
	dataset.addColumn('Parcela');
	dataset.addColumn('Tipo');
	dataset.addColumn('Nome');
	dataset.addColumn('Valor');
	dataset.addColumn('Vencimento');
	dataset.addColumn('VencimentoReal');
	dataset.addColumn('codigoFornece');
	dataset.addColumn('lojaFornece');
	
	for(i = 0; i < objdata.length; i++){
		dataset.addRow(new Array(objdata[i]['Codigo'],
						objdata[i]['Filial'],
						objdata[i]['Prefixo'],
						objdata[i]['Numero'],
						objdata[i]['Parcela'],
						objdata[i]['Tipo'],
						objdata[i]['Nome'],
						objdata[i]['Valor'],
						objdata[i]['Vencimento'],
						objdata[i]['VencimentoReal'],
						objdata[i]['codigoFornece'],
						objdata[i]['lojaFornece']));
	};
		
    return dataset;    
}