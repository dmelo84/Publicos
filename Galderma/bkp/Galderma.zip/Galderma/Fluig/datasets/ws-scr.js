function defineStructure() {

}
function onSync(lastSyncDate) {

}
function createDataset(fields, constraints, sortFields) {
	var dataset = DatasetBuilder.newDataset();
	dataset.addColumn("RETORNO");
	
	var data = {
		companyId: getValue("WKCompany") + "",
		serviceCode: 'API_QNTWS01',
		endpoint: '/rest/QNTWS02',
		method: 'POST',
		timeoutService: '100',
		params: 
					{
						"Filial":"010101",
					    "Pedido":"001487",
					    "RECNO":"3035",
						"CodUsr":"000030",
						"CodAprov":"000008",
						"Tipo":"IP",
						"Aprovado":"03",
						"AprOrigem": "000008",
						"UsrOrigem": "000030"
					}
				
	}
	
	var clientService = fluigAPI.getAuthorizeClientService();
	var vo = clientService.invoke(JSON.stringify(data));
	 
    if(vo.getResult()== null || vo.getResult().isEmpty()){
        dataset.addRow(new Array("2"));
    }else{
        log.info("FINAL >>>> " + vo.getResult());
        dataset.addRow(new Array(vo.getResult()));
    }
    
    return dataset;
}function onMobileSync(user) {

}