function createDataset(fields, constraints, sortFields) {
	
	var ccod="";
    
	var servicoURL = "http://localhost:8083/rest/PLANODECONTAS_CT1"  
    
    var myApiConsumer =  oauthUtil.getGenericConsumer("","", "", "");    
    var data = myApiConsumer.get(servicoURL);    
   
  
    var dataset = DatasetBuilder.newDataset();       
    
    var objdata = JSON.parse(data);    
   
    dataset.addColumn('codigo');
	dataset.addColumn('descricao');
	
	for(i = 0; i < objdata.length; i++){
		dataset.addRow(new Array(objdata[i]['codigo'], objdata[i]['descricao']));
	};
		
    return dataset;    
}