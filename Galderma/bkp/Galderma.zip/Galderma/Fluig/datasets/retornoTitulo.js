function createDataset(fields, constraints, sortFields) {
	/*
    var cEmpresa = DatasetFactory.createConstraint("DDD", "47", "47", ConstraintType.MUST);
    var cFilAtu  = DatasetFactory.createConstraint("DDD", "47", "47", ConstraintType.MUST);
    */
	var cEmp = '99'//$("#empresa").val();
	var cFilAtu = '01' //$("#filial").val();
	var cAlias   = "SE1";
	var endPoint = "http://localhost:8083/rest/TITULOS_FINANCEIRO?cAlias="
	var servicoURL = endPoint+cAlias+"&cEmp="+cEmp+"&cFilAtu="+cFilAtu;    
    var myApiConsumer =  oauthUtil.getGenericConsumer("","", "", "");    
    var data = myApiConsumer.get(servicoURL);
	/*
    var dataset = DatasetFactory.getDataset("exemploFiltro", null, new Array(c1), null);
    */
    var dataset = DatasetBuilder.newDataset();       
    
    var objdata = JSON.parse(data);    
   
    dataset.addColumn('cAlias');
    dataset.addColumn('Codigo');
    dataset.addColumn('Nome');
	dataset.addColumn('Prefixo');
	dataset.addColumn('Numero');
	dataset.addColumn('Valor');
	dataset.addColumn('Vencimento');
	dataset.addColumn('Tipo');
	dataset.addColumn('Parcela');
	
	for(i = 0; i < objdata.length; i++){
		dataset.addRow(new Array(cAlias, objdata[i]['Codigo'], objdata[i]['Nome'], objdata[i]['Prefixo'], objdata[i]['Numero'], objdata[i]['Valor'], objdata[i]['Vencimento'],objdata[i]['Tipo'],objdata[i]['Parcela']));
	};
   
    return dataset;   
}